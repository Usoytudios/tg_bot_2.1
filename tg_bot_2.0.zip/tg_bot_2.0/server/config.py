import os
bot_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

token = ''

db_path = 'database/bot_database.db'

ban_time = 60 

limit = 3

words_filter = False


WORDS = {
    "блять": "капец",
    "мат2": "синоним2",
}