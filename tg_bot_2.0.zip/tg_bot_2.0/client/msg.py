# client/broadcast.py

import os
import asyncio
from datetime import datetime
import aiosqlite
from aiogram import Bot
from server.config import *

db_abs_path = os.path.join(bot_dir, db_path)
msg = os.path.join(bot_dir, "msg.txt")

async def send_broadcast_message():
    try:
        with open(msg, "r", encoding="utf-8") as f:
            broadcast_message = f.read().strip()
    except Exception as e:
        print(f"Ошибка при чтении файла {msg}: {e}")
        return

    if not broadcast_message:
        print("Файл broadcast_message.txt пуст.")
        return

    bot = Bot(token=token)
    current_timestamp = datetime.now().timestamp()
    async with aiosqlite.connect(db_abs_path) as db:
        query = "SELECT telegram_id FROM users WHERE banned_until IS NULL OR banned_until <= ?"
        async with db.execute(query, (current_timestamp,)) as cursor:
            users = await cursor.fetchall()
    if not users:
        print("Нет пользователей для рассылки.")
        return
    for (tg_id,) in users:
        try:
            await bot.send_message(tg_id, broadcast_message)
            print(f"Сообщение отправлено пользователю {tg_id}")
        except Exception as e:
            print(f"Ошибка при отправке сообщения пользователю {tg_id}: {e}")

    await bot.session.close()

if __name__ == '__main__':
    asyncio.run(send_broadcast_message())
